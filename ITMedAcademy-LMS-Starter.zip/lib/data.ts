export const courses = [
  {title:"IMAT Biology: Core Concepts",category:"IMAT Preparation",progress:68,lessons:"24 of 36 lessons",color:"blue"},
  {title:"Chemistry for IMAT",category:"IMAT Preparation",progress:42,lessons:"15 of 35 lessons",color:"violet"},
  {title:"Logical Reasoning & Problem Solving",category:"Practice",progress:25,lessons:"8 of 32 lessons",color:"amber"},
];
export const tasks = [
  {day:"22",month:"OCT",title:"Biology mock test",meta:"20 questions · 30 minutes",status:"Due soon",tone:"amber"},
  {day:"24",month:"OCT",title:"Chemistry revision session",meta:"Live class · 17:00 CET",status:"Upcoming",tone:"blue"},
  {day:"27",month:"OCT",title:"Logical reasoning practice",meta:"15 questions · 20 minutes",status:"Planned",tone:"green"},
];
export const students = [
  {name:"Aarav Sharma",email:"aarav@example.com",course:"IMAT Biology",progress:76,status:"Active"},
  {name:"Sara Khan",email:"sara@example.com",course:"Chemistry for IMAT",progress:52,status:"Active"},
  {name:"Marco Rossi",email:"marco@example.com",course:"Logical Reasoning",progress:31,status:"Needs support"},
  {name:"Maya Patel",email:"maya@example.com",course:"IMAT Biology",progress:91,status:"Active"},
];