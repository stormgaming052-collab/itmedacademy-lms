-- ITMedAcademy LMS starter schema (apply in Supabase SQL Editor after review).
-- This initial schema is intentionally small. Expand it before production use.
create type public.app_role as enum ('student', 'instructor', 'admin');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'student',
  created_at timestamptz not null default now()
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text not null default '',
  category text not null default 'IMAT Preparation',
  instructor_id uuid references public.profiles(id) on delete set null,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.modules (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  position int not null default 0
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  title text not null,
  content_url text,
  duration_minutes int not null default 0,
  position int not null default 0
);

create table public.enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  progress int not null default 0 check (progress between 0 and 100),
  created_at timestamptz not null default now(),
  unique(student_id, course_id)
);

create table public.lesson_completions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz not null default now(),
  unique(student_id, lesson_id)
);

create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references public.courses(id) on delete cascade,
  title text not null,
  questions jsonb not null default '[]'::jsonb,
  published boolean not null default false
);

create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  score numeric not null default 0,
  answers jsonb not null default '[]'::jsonb,
  submitted_at timestamptz not null default now()
);

create table public.live_sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  instructor_id uuid references public.profiles(id) on delete set null,
  starts_at timestamptz not null,
  meeting_url text,
  course_id uuid references public.courses(id) on delete set null
);

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.modules enable row level security;
alter table public.lessons enable row level security;
alter table public.enrollments enable row level security;
alter table public.lesson_completions enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.live_sessions enable row level security;

create policy "Users can read their profile" on public.profiles for select to authenticated using (id = auth.uid());
create policy "Users can update their own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "Anyone can read published courses" on public.courses for select using (published = true);
create policy "Students can read their enrollments" on public.enrollments for select to authenticated using (student_id = auth.uid());
create policy "Students can manage their own lesson completions" on public.lesson_completions for all to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());
create policy "Students can read their quiz attempts" on public.quiz_attempts for select to authenticated using (student_id = auth.uid());
create policy "Students can create their quiz attempts" on public.quiz_attempts for insert to authenticated with check (student_id = auth.uid());
create policy "Authenticated users can read published live sessions" on public.live_sessions for select to authenticated using (true);

-- NOTE: Instructor/admin mutation policies, secure role assignment, auth profile trigger,
-- and full policies for modules, lessons, quizzes, storage, assignments and submissions
-- must be added before production deployment. Never expose a Supabase service-role key in browser code.
