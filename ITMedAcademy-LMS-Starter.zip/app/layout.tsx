import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "ITMedAcademy | Learning Portal",
  description: "Study medicine in Italy with ITMedAcademy: courses, exam preparation and student support."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}