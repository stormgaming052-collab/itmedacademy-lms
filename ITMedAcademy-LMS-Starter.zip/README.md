# ITMedAcademy LMS Starter

A branded Next.js starter inspired by the supplied LMS demo. It includes a responsive public homepage, student portal, instructor portal, admin portal, sample courses, sample learner records, a browser-only sample quiz, and a starter Supabase schema.

## Important status

This is a **starter prototype**, not yet a production-ready full-stack LMS. Dashboard numbers and course records are sample data. The login page is a preview-only form, not real authentication. Create/edit buttons are UI placeholders. Do not use it for real student records until authentication, server-side role checks, Row Level Security, and all database mutations are implemented and tested.

## Requirements

- Node.js 20.9+ recommended
- npm
- A Supabase project for real authentication/database features

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

The app can be previewed without Supabase because the initial pages use demo data. The real backend is not yet connected.

## Deploy to Vercel

1. Push the project to a new GitHub repository.
2. Import that repository in Vercel.
3. Keep the default Next.js build settings.
4. Deploy the UI prototype.
5. For backend work, create a Supabase project and add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` to Vercel Environment Variables.
6. Review and apply `supabase/schema.sql` in the Supabase SQL Editor.
7. Implement and test the remaining authentication, role policies and CRUD actions before real use.

## Routes

- `/` public homepage
- `/login` preview login form
- `/dashboard` student dashboard
- `/courses` course catalogue
- `/my-learning` learning progress
- `/quizzes` interactive sample quiz
- `/live-classes`, `/assignments`, `/certificates`
- `/instructor` and instructor subpages
- `/admin` and admin subpages

## Next milestones

1. Supabase SSR auth, signup/login/logout, password reset and callback.
2. Profile creation trigger and secure role provisioning.
3. Server-side role-based route protection and RLS policies.
4. Real course/module/lesson CRUD and enrollment.
5. Persistent lesson progress, quiz attempts and grading.
6. Assignments/submissions, live sessions, certificates and notifications.
7. Automated tests, accessibility checks, production security review.
