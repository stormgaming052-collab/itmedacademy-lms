import Link from "next/link";
import { Activity, AlarmClock, Award, BookOpen, CalendarDays, ChartNoAxesCombined, CheckSquare, ChevronRight, ClipboardList, GraduationCap, LayoutDashboard, LifeBuoy, LogOut, MessageSquare, Search, Settings, ShieldCheck, Users, Video, WalletCards, FileText, Bell, Menu, PlayCircle, Plus, ArrowUpRight } from "lucide-react";
import type { ReactNode } from "react";

const navStudent = [
  {label:"Overview",href:"/dashboard",icon:LayoutDashboard},
  {label:"Course catalogue",href:"/courses",icon:BookOpen},
  {label:"My learning",href:"/my-learning",icon:PlayCircle},
  {label:"Mock exams & quizzes",href:"/quizzes",icon:ClipboardList},
  {label:"Live classes",href:"/live-classes",icon:Video},
  {label:"Assignments",href:"/assignments",icon:CheckSquare},
  {label:"Certificates",href:"/certificates",icon:Award},
];
const navInstructor = [
  {label:"Overview",href:"/instructor",icon:LayoutDashboard},
  {label:"My courses",href:"/instructor/courses",icon:BookOpen},
  {label:"Students",href:"/instructor/students",icon:Users},
  {label:"Assignments",href:"/instructor/assignments",icon:CheckSquare},
  {label:"Live sessions",href:"/instructor/live-classes",icon:Video},
  {label:"Analytics",href:"/instructor/analytics",icon:ChartNoAxesCombined},
];
const navAdmin = [
  {label:"Overview",href:"/admin",icon:LayoutDashboard},
  {label:"User management",href:"/admin/users",icon:Users},
  {label:"Courses",href:"/admin/courses",icon:BookOpen},
  {label:"Categories",href:"/admin/categories",icon:ClipboardList},
  {label:"Reports & analytics",href:"/admin/analytics",icon:ChartNoAxesCombined},
  {label:"Platform settings",href:"/admin/settings",icon:Settings},
];
export function Shell({children,role="student",active="/dashboard"}:{children:ReactNode;role?:"student"|"instructor"|"admin";active?:string}) {
  const nav = role==="admin"?navAdmin:role==="instructor"?navInstructor:navStudent;
  const roleName = role==="admin"?"Administrator":role==="instructor"?"Instructor":"Student";
  return <div className="app-shell">
    <aside className="sidebar">
      <Link className="brand" href="/dashboard"><span className="brand-mark">IT</span><span>ITMedAcademy<small style={{display:"block",fontSize:9,fontWeight:500,color:"#9db5d6",marginTop:2}}>LEARN · PRACTICE · SUCCEED</small></span></Link>
      <div><div className="side-label">{roleName} portal</div><nav className="side-nav">{nav.map(n=>{const I=n.icon;return <Link key={n.href} href={n.href} className={`side-link ${active===n.href?"active":""}`}><I size={17}/>{n.label}</Link>})}</nav></div>
      <div><div className="side-label">Support</div><nav className="side-nav"><Link className="side-link" href="/messages"><MessageSquare size={17}/>Messages</Link><Link className="side-link" href="/help"><LifeBuoy size={17}/>Help centre</Link></nav></div>
      <div className="side-bottom"><Link className="side-link" href="/settings"><Settings size={17}/>Settings</Link><Link className="side-link" href="/login"><LogOut size={17}/>Sign out</Link></div>
    </aside>
    <div className="main">
      <div className="mobile-head"><Link className="brand" href="/dashboard"><span className="brand-mark">IT</span>ITMedAcademy</Link><Menu size={21}/></div>
      <header className="topbar"><div className="search"><Search size={14} style={{display:"inline",marginRight:8}}/>Search courses, lessons, tests...</div><div className="user-chip"><Bell size={17}/><div className="avatar">ST</div><div><b>Student Test</b><div style={{color:"#718096",fontSize:10}}>{roleName}</div></div></div></header>
      {children}
    </div>
  </div>;
}
export function Heading({eyebrow,title,subtitle,action}:{eyebrow:string;title:string;subtitle:string;action?:ReactNode}) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><div className="muted">{subtitle}</div></div>{action}</div>;
}
export function Stat({icon:Icon,label,value,detail}:{icon:any;label:string;value:string;detail:string}) {
  return <div className="stat"><div className="stat-top"><div className="muted">{label}</div><div className="stat-icon"><Icon size={18}/></div></div><div className="stat-value">{value}</div><div className="trend">{detail}</div></div>;
}
export function Panel({title,link,children}:{title:string;link?:string;children:ReactNode}) {
  return <section className="panel"><div className="panel-title"><h2>{title}</h2>{link&&<Link className="text-link" href={link}>View all <ArrowUpRight size={12} style={{display:"inline"}}/></Link>}</div>{children}</section>;
}
export function ProgressRow({title,meta,progress,index=0}:{title:string;meta:string;progress:number;index?:number}) {
  const icons=[BookOpen,GraduationCap,Activity];const Icon=icons[index%icons.length];
  return <div className="course-row"><div className="course-thumb"><Icon size={23}/></div><div className="course-info"><strong>{title}</strong><small>{meta}</small><div className="progress"><span style={{width:`${progress}%`}}/></div></div><div className="percent">{progress}%</div></div>;
}
export function TaskRow({day,month,title,meta,status,tone}:{day:string;month:string;title:string;meta:string;status:string;tone:string}) {
  return <div className="task"><div className="task-date"><b>{day}</b><small>{month}</small></div><div className="task-info"><strong>{title}</strong><small>{meta}</small></div><span className={`pill ${tone==="green"?"green":tone==="amber"?"amber":""}`}>{status}</span></div>;
}
export function FeatureCard({icon:Icon,title,description,href,cta="Open"}:{icon:any;title:string;description:string;href:string;cta?:string}) {
 return <div className="feature"><div className="feature-icon"><Icon size={21}/></div><h3>{title}</h3><p>{description}</p><Link className="text-link" href={href}>{cta} <ChevronRight size={13} style={{display:"inline"}}/></Link></div>;
}